package client.job.ia;

import client.job.Container;


/**
 * IA of a player.
 */
public class IA3 extends IA
{
    private class Move
    {
        private List<Move>  next;
        private Move        previous;
        private int[]       move;

        public Move (int row, int col, int corner)
        {
            this.move = new int[] { row, col, corner };
        }

        public void addNext (Move next)
        {
            this.next.add(next);
        }

        public void setPrevious (Move previous)
        {
            this.previous = previous;
        }

        public Move getNext (int index)
        {
            return this.next.get(index);
        }

        public Move getPrevious ()
        {
            return this.previous;
        }
    }

	/**
	 * Plays for the player, according to its IA level.
	 */
	@Override
	public String calcResponse ()
    {
        Integer[] answer;

        if (this.containers == null)
            return "";


        // Looks for all the possible moves and saves them
        List<Integer[]> moves = new ArrayList<Integer[]>();
        for (int i = 0; i < this.containers.length; i++)
        {
            for (int j = 0; j < this.containers[i].length; j++)
            {
                for (int k = 1; k <= 4; k++)
                {
                    if ( this.containers[i][j].getLock(k).getOwner() == -1 )
                        moves.add( new Integer[] { i, j, k } );

					System.out.println((i + 1) + "" + (char)(j + 'A') + "" + k + " : " + this.containers[i][j].getLock(k));
                }
            }
        }

        // Level 2 : Random but not the one already taken
        answer = moves.get( (int)(Math.random()*moves.size()) );

        try
        {
            // Thread.sleep(10000);
        } catch (Exception e) {}

        String toSend = String.format("%d%c%d", answer[0] + 1, answer[1]+'A', answer[2]);
        this.saveAction(toSend, 0);
        return toSend;
    }
}
