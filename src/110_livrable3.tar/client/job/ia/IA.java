package client.job.ia;

import client.job.Container;
import client.job.Twistlock;


/**
 * IA of a player.
 */
public abstract class IA
{
	protected Container[][]	containers;


	public void receiveContainers (String message)
    {
        String[] arrRows = message.split("\n")[1].substring(4).split("\\|");

        int row = arrRows.length;
        int col = arrRows[0].split(":").length;

        // Creation of the twistlocks
        Twistlock[][] twistlocks = new Twistlock[col + 1][row + 1];
        for (int i = 0; i < twistlocks.length; i++)
        {
            for (int j = 0; j < twistlocks[i].length; j++)
            {
                twistlocks[i][j] = new Twistlock();
            }
        }

        // Creation of the containers
        this.containers = new Container[row][col];
        for (int i = 0, n = arrRows.length; i < n; i++)
        {
            String[] arrCols = arrRows[i].split(":");
            for (int j = 0, m = arrCols.length; j < m; j++)
            {
                this.containers[i][j] = new Container(i, j, Integer.parseInt(arrCols[j]), twistlocks[i][j], twistlocks[i + 1][j], twistlocks[i][j + 1], twistlocks[i + 1][j + 1]);
            }
        }
    }

    public void saveAction (String action, int owner)
    {
		System.out.println(action);
        this.containers[action.charAt(0)-'1'][action.charAt(1)-'A'].capture(action.charAt(2)-'0', owner);
    }

	/**
	 * Plays for the player, according to its IA level.
	 */
	public abstract String calcResponse ();
}
