package twistlock.window;

import javax.swing.*;
import java.awt.Color;
import java.awt.BorderLayout;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;


/**
 * Only window of the user interface of the game.
 * @author Javane
 * @version 2018-03-26
 */
public class Window extends JFrame
{
	/** Colors of the players, in the order of their index */
	static final Color[] 	playerColors 	= new Color[] { Color.red, Color.green };
	/** Width of the current window. */
	static int				width;
	/** Height of the current window. */
	static int				height;
	/** Size factor of the window. */
	static float			sizeFactor;
	/** The swing frame wrapped by the {@link Window}. */
	private JFrame 			frame;


	/**
	 * Creates the window which will be containing the entire user interface.
	 */
	public Window ()
	{
		super("TwistLock");

		this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		this.setToMenu();

		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}

	/**
<<<<<<< HEAD
=======
	 * Event called on window's resizing.
	 */
	public void onResize ()
	{
		Window.width	= this.getSize().width;
		Window.height	= this.getSize().height;

		// Gets the current dimensions of the frame, and saves the lower one.
		int lowerValue = Window.height;
		if (getWidth() < lowerValue)
			lowerValue = Window.width;

		Window.sizeFactor = lowerValue / 1080f;

		// If the game is loaded...

	}

	/**
>>>>>>> 0e64f4b344bb42f03d85b7f4b57d947f9ec3d4dc
	 * Sets the main display to the menu.
	 */
	public void setToMenu ()
	{
		this.changeShownPanel( new MenuPanel() );
		this.pack();
	}

	/**
	 * Sets the main display to the game.
	 */
	public void setToGame ()
	{
		this.setExtendedState(JFrame.MAXIMIZED_BOTH);

		GamePanel gp = new GamePanel();
		this.changeShownPanel(gp);
	}

	/**
	 * Sets the main panel of the window to the panel passed as parameter.
	 * @param pan Panel to display in the window.
	 */
	void changeShownPanel (JPanel pan)
	{
		this.setContentPane(pan);
	}
}
