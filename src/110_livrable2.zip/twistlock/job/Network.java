package twistlock.job;

import java.net.DatagramSocket;
import java.net.DatagramPacket;

import twistlock.util.InetAddressWithPort;
import twistlock.Controller;

public class Network
{
	public static final int DEFAULT_PORT = 2009;
	
	private DatagramSocket ds;
	
	public Network ()
	{
		this(Network.DEFAULT_PORT);
	}
	
	public Network (int port)
	{
		try
		{
			this.ds = new DatagramSocket(port);
		}
		catch(Exception e) {}
	}
	
	public String getMessage (InetAddressWithPort inetAddressWithPort)
	{
		DatagramPacket msg = null;
		
		do
		{
			if (msg != null && ! inetAddressWithPort.equals(msg.getAddress(), msg.getPort() ))
				Controller.getController().sendMessage("91",new InetAddressWithPort(msg.getAddress(), msg.getPort()));
			
			msg = new DatagramPacket(new byte[512], 512);
			
			try
			{
				ds.receive(msg);
			}
			catch(Exception e) {}
			
		} while( ! inetAddressWithPort.equals(msg.getAddress(), msg.getPort() ));
		
		byte[] data = msg.getData();
		
		int i = 0;
		for (;i < data.length && data[i] != 0; i++);
			
		byte[] newData = new byte[i];
		
		for (int j = 0 ; j < newData.length ; j++)
			newData[j] = data[j];
		
		msg.setData(newData);
		
		try
		{
			return new String( msg.getData() ,"UTF-8");
		}
		catch (Exception e)
		{}
		
		return null;
	}
	
	public DatagramPacket getMessage ()
	{
		DatagramPacket msg = null;
		
		
		try
		{
			msg = new DatagramPacket(new byte[512], 512);
			ds.receive(msg);
		}
		catch(Exception e) {}
		
		byte[] data = msg.getData();
		
		int i = 0;
		for (;i < data.length && data[i] != 0; i++);
			
		byte[] newData = new byte[i];
		
		for (int j = 0 ; j < newData.length ; j++)
			newData[j] = data[j];
		
		msg.setData(newData);
		return msg;
	}
	
	public void sendMessage (InetAddressWithPort inetAddressWithPort, String message)
	{
		try
		{
			DatagramPacket reponse = new DatagramPacket(message.getBytes("UTF-8"), new String( message.getBytes("UTF-8") ).length(), inetAddressWithPort.getInetAddress(), inetAddressWithPort.getPort() );
		
			this.ds.send(reponse);
		}
		catch(Exception e) {}
	}
	
	
}
