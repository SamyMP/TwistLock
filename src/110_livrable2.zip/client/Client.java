package client;


/**
 * Panel containing a log and a field for the player to input in action.
 */
public class Client
{
	// private static int IALevel = 0;
	private static Window window;
	private static Network network;

	public static Network createNetwork(String serverIp)
	{
		network = new Network(serverIp);
		return network;
	}

	public static void main(String[] args)
	{
		window = new Window();
	}

	public static Network getNetwork()
	{
		return network;
	}

	public static Window getWindow()
	{
		return window;
	}

    /**
     * Plays for the player, according to its IA level.
     */
    // public int[] calcResponse ()
    // {
    //     // Level 1 : Random
    //     int nbRow 	= this.containers.length;
    //     int nbCol 	= this.containers[0].length;
	//
    //     int row 	= 0;
    //     int col 	= 0;
    //     int corner	= 0;
	//
	//
    //     if (this.IALevel == 1)
    //     {
    //         row		= (int)(Math.random()*nbRow);
    //         col		= (int)(Math.random()*nbCol);
    //         corner	= (int)(Math.random()*4) + 1;
    //     }
	//
    //     return new int[] { row, col, corner };
    // }
}
