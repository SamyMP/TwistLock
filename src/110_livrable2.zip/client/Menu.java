package client;

import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.GridLayout;
import javax.swing.JButton;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class Menu extends JPanel implements ActionListener
{
	private JPanel principal;
	private JTextField ipServeur;
	private JTextField pseudo;
	private JButton submit;

	public Menu()
	{

		this.setLayout( new GridLayout(3,2) );

		this.add(new JLabel("Ip du serveur : "));
		ipServeur = new JTextField();
		this.add(ipServeur);

		this.add(new JLabel("pseudo : "));
		pseudo = new JTextField();
		this.add(pseudo);

		this.add(new JLabel(" "));
		submit = new JButton("Valider");
		submit.addActionListener(this);
		this.add(submit);


	}
	public void actionPerformed( ActionEvent e )
	{
		if (!ipServeur.getText().matches("([0-9]{1,3}.){3}[0-9]{1,3}"))
		{
			JOptionPane d = new JOptionPane();
			d.showMessageDialog( this, "L'adresse ip n'est pas valide", "IP invalide", JOptionPane.ERROR_MESSAGE);
			return;
		}
		Network n = Client.createNetwork(ipServeur.getText());
		n.sendMessage(pseudo.getText());
	}
}
