package client;

import java.net.DatagramSocket;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.SocketTimeoutException;
import javax.swing.JOptionPane;

public class Network
{
	private InetAddress serverIp;
	private DatagramSocket socket;

	public Network(String serverIp)
	{
		try
		{
			this.serverIp = InetAddress.getByName(serverIp);
			socket = new DatagramSocket();
			socket.setSoTimeout(5000);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

		new Thread()
		{
			private Network network;

			public Thread setNetwork(Network network)
			{
				this.network = network;
				return this;
			}

			public void run()
			{
				while(true)
				{
					try
					{
						DatagramPacket msg = new DatagramPacket(new byte[512], 512);
						socket.receive(msg);
						socket.setSoTimeout(1000 * 60 * 60 * 24);
						network.printServerMessage(new String(msg.getData()));
					}
					catch (SocketTimeoutException e)
					{
						break;
					}
					catch (Exception e)
					{
						e.printStackTrace();
					}
				}
				JOptionPane.showMessageDialog( Client.getWindow(), "Le serveur n'existe pas où n'a pas répondu à temps.", "Timeout", JOptionPane.ERROR_MESSAGE);
			}
		}.setNetwork(this).start();
	}

	void printServerMessage(String message)
	{
		System.out.println(message);
		Client.getWindow().addLog(message);
		if (message.startsWith("01"))
		{
			Client.getWindow().setGamePanel();
		}
		if (message.startsWith("10"))
		{
			Client.getWindow().canPlay(true);
		}
	}

	public void sendMessage(String message)
	{
		DatagramPacket envoi = new DatagramPacket(
			message.getBytes(),
			message.length(),
			serverIp,
			2009
		);

		try
		{
			System.out.println(message);
			socket.send(envoi);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

		DatagramPacket msg = new DatagramPacket(new byte[512], 512);
	}
}
