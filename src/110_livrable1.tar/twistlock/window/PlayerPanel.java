package twistlock.window;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;

import twistlock.job.Player;
import java.awt.geom.Path2D;
import java.awt.BasicStroke;
/**
 * Panel displaying the information about the player.
 */
class PlayerPanel extends JPanel
{
	private Player player;

	private BufferedImage image;


	/**
	 * Creates a panel for the player with the specified index.
	 * @param player Index of the player.
	 */
	PlayerPanel (Player player)
	{
		super();

		this.player = player;

		image = new BufferedImage(550, 1000, BufferedImage.TYPE_INT_ARGB);
		draw();
		repaint();
	}

	/**
	 * Redraws the panel.
	 * @param g Player panel's {@link Graphics}.
	 */
	@Override
	protected void paintComponent (Graphics g)
	{
		super.paintComponent(g);

		Graphics2D g2d = (Graphics2D) g;
		g2d.setColor(Color.black);

		g2d.drawImage(image.getScaledInstance(100, 200, Image.SCALE_SMOOTH), null, null);
		g2d.setFont(g2d.getFont().deriveFont(15.0f));
		g2d.drawString(player.getPseudo(), 0, 220);
		int row = 0;
		int col = 0;
		for (int i = 0; i < player.getTwistLock(); i++)
		{
			if (i == 10)
			{
				row++;
				col = 0;
			}
			g2d.fillOval(1 + 10 * col, 230 + 10 * row, 9, 9);
			col++;
		}
		g2d.drawString(player.getScore() + "", 0, 270);
	}

	/**
	 * Draw the image attached to the player's panel.
	 */
	void draw ()
	{
		Graphics2D g2 = image.createGraphics();

	    g2.setStroke(new BasicStroke(3));
		g2.setColor(Window.playerColors[player.getId()]);
		g2.drawLine(100, 50, 400, 50);
		g2.drawLine(100, 50, 100, 750);
		g2.drawLine(400, 50, 400, 750);
		g2.drawLine(100, 350, 400, 350);
		g2.drawLine(100, 50, 400, 350);
		g2.drawLine(100, 350, 400, 50);
		g2.drawLine(100, 350, 400, 750);
		g2.drawLine(100, 750, 400, 350);

		Path2D.Double shape = new Path2D.Double();
		shape.moveTo(100, 750);
		shape.lineTo(400, 750);
		shape.lineTo(500, 850);
		shape.lineTo(0, 850);
		g2.fill(shape);

		g2.fillRect(0, 850, 500, 250);

		this.repaint();
	}
}
