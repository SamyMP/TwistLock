package twistlock.window;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.text.AttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyleContext;

import twistlock.Controller;
import twistlock.window.PlayerPanel;
import twistlock.job.Player;

/**
 * Panel containing the whole game of Twistlock, including the {@link PlayerPanel} and {@link GameCanvas}.
 * @author Javane
 * @version 2018-03-26
 */
class GamePanel extends JPanel implements KeyListener, ActionListener
{
	/** Displays a recap of all the actions performed during the last players' turns */
	private JTextPane   log;
	/** Text field where the player enters the three characters corresponding to the action he wants to perform */
	private JTextField  choice;
	/** Button used to submit what is written in {@link #choice}. */
	private JButton     submit;


	/**
	* Creates the {@link GamePanel} to display in the current window.
	*/
	GamePanel()
	{
		this.setLayout(new BorderLayout());

		JPanel south = new JPanel( new GridLayout(2,1));

		this.log = new JTextPane();
		this.log.setEditable(false);
		this.log.setBackground(Window.playerColors[0]);
		JScrollPane scroll = new JScrollPane(log);

		south.add(scroll);

		JPanel saisie = new JPanel( new BorderLayout() );
		choice = new JTextField();
		choice.addKeyListener(this);
		saisie.add(choice);

		submit = new JButton("Valider");
		submit.addActionListener(this);
		saisie.add(submit,"East");

		south.add(saisie);

		this.add(new GameCanvas());
		this.add(south,"South");

		Player[] tabPlayers = Controller.getController().getPlayers();

		JPanel westPan = new JPanel(true);
		westPan.setLayout(new BoxLayout(westPan, BoxLayout.Y_AXIS));

		for (int i = 0; i < tabPlayers.length; i+=2)
		{
			PlayerPanel playerPan = new PlayerPanel(tabPlayers[i]);
			playerPan.setPreferredSize(new Dimension(100, 300));
			westPan.add(playerPan);
		}
		this.add(westPan, "West");

		JPanel eastPan = new JPanel(true);
		eastPan.setLayout(new BoxLayout(eastPan, BoxLayout.Y_AXIS));

		for (int i = 1; i < tabPlayers.length; i+=2)
		{
			PlayerPanel playerPan = new PlayerPanel(tabPlayers[i]);
			playerPan.setPreferredSize(new Dimension(100, 300));
			eastPan.add(playerPan);
		}
		this.add(eastPan, "East");
	}

	/**
	* Adds a message with a certain color in the recap log of the game.
	* @param msg Message to display.
	* @param c Color of the message.
	*/
	private void addLog (String msg, Color c)
	{
		StyleContext sc = StyleContext.getDefaultStyleContext();
		AttributeSet aSet = sc.addAttribute(SimpleAttributeSet.EMPTY, StyleConstants.Foreground, c);

		int len = log.getDocument().getLength();
		this.log.setEditable(true);
		this.log.setCaretPosition(len);
		this.log.setCharacterAttributes(aSet, false);
		this.log.replaceSelection("\n" + msg);
		this.log.setCaretPosition(log.getDocument().getLength());
		this.log.setEditable(false);
	}

    /**
     * Sends the action entered by the player.
     */
	public void sendChoice ()
	{
		String tmp = choice.getText();
		tmp.replaceAll("[ \t\n]*", "");
		int row,corner;
		char col;

		try
        {
			row     = Integer.parseInt(tmp.charAt(0) + "");
			col     = (tmp.charAt(1));
			col     = Character.toUpperCase(col);
			corner  = Integer.parseInt(tmp.charAt(2) + "");

			if ( !Controller.getController().doAction(row-1, col-'A', corner) )
            {
                JOptionPane d = new JOptionPane();
                d.showMessageDialog( this,"Coup illégal.\nVous avez une pénalité.","Coup illégal",JOptionPane.ERROR_MESSAGE);
            }
		}
		catch (Exception ex)
        {
			JOptionPane d = new JOptionPane();
			d.showMessageDialog( this,"Saisie incorrecte.","Avertissement",JOptionPane.ERROR_MESSAGE);
		}
		choice.setText("");
	}

	JTextPane getColorArea()
	{
		return this.log;
	}

	public void keyTyped (KeyEvent e) {}

	public void keyReleased (KeyEvent e) {}

	public void keyPressed (KeyEvent e)
	{
		if (e.getKeyCode() == KeyEvent.VK_ENTER){ sendChoice(); }
	}

	public void actionPerformed (ActionEvent e)
	{
		if ( e.getSource() == submit ) { sendChoice();}
	}
}
