package twistlock.window;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;
import java.util.*;

import twistlock.Controller;

/**
 * Panel containing the main menu of the Twistlock game.
 * @author Javane
 * @version 2018-03-26
 */
class MenuPanel extends JPanel implements ActionListener,ChangeListener
{
	// c'est le panel qu'on a au demarrage avec un formulaire pour le nombre de joueurs et tout le bordel a demander pour creer le jeu
	// 4 Textfield noms joueurs
	private PanelJoueur panelJoueurs;
	// Checkbox aleatoire ou fixe
	// deux TextField pour taille ( 4 à 9 )
	private JPanel taille;
    private JSpinner sLig;
    private JSpinner sCol;
    private JButton aleatoire;
	// deux boutons confirmer et quitter*
	private JPanel boutons;
    private JButton confirmer;
    private JButton quitter;

    MenuPanel()
    {
        setLayout( new BoxLayout(this, BoxLayout.Y_AXIS));

        panelJoueurs = new PanelJoueur();
        panelJoueurs.setAlignmentX(BoxLayout.Y_AXIS);
        add(panelJoueurs);

		add(Box.createRigidArea(new Dimension(0,5)));

        taille = new JPanel( new GridLayout(1,3,5,5));
        sLig = new JSpinner();
        sLig.setValue(7);
        sLig.addChangeListener(this);
        taille.add(sLig);
        sCol = new JSpinner();
        taille.add(sCol);
        sCol.setValue(7);
        sCol.addChangeListener(this);
        aleatoire = new JButton("aleatoire");
        aleatoire.addActionListener(this);
        taille.add(aleatoire);
        taille.setAlignmentX(BoxLayout.Y_AXIS);
        add(taille);

		add(Box.createRigidArea(new Dimension(0,5)));

        boutons = new JPanel( new GridLayout(1,2,5,5));
        confirmer = new JButton("Confirmer");
        confirmer.addActionListener(this);
        boutons.add(confirmer);
        quitter = new JButton("Quitter");
        quitter.addActionListener(this);
        boutons.add(quitter);
        boutons.setAlignmentX(BoxLayout.Y_AXIS);
        add(boutons);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e)
    {
        if ( e.getSource() == aleatoire )
        {
            int delta = 6;
            int min = 4;
            int lig = (int)(Math.random()*delta) + min;
            int col = (int)(Math.random()*delta) + min;
            sLig.setValue(lig);
            sCol.setValue(col);
        }
        if ( e.getSource() == confirmer )
        {
            int lig = (int) sLig.getValue();
            int col = (int) sCol.getValue();
            String[] players = panelJoueurs.getJoueurs();
            Controller.getController().createGame(col,lig,players);
        }
        if ( e.getSource() == quitter )
        {
            System.exit(0);
        }
    }

    public void stateChanged(ChangeEvent e)
    {
        JSpinner j = (JSpinner) ( e.getSource());
        int value = (int) (j.getValue());
        if ( value < 4 )
            j.setValue(4);
        else
            if ( value > 9 )
                j.setValue(9);
    }

    public static void main(String[] args)
    {
        new MenuPanel();
    }

}

class PanelJoueur extends JPanel implements ActionListener
{
    ArrayList<String> alJoueur;
    ArrayList<JTextField> alField;
    JPanel joueurs;
    JButton add;
    JButton remove;

    PanelJoueur()
    {
        super();
		alField = new ArrayList<JTextField>();
        alJoueur = new ArrayList<String>();
        alJoueur.add("");
        alJoueur.add("");
        setLayout( new BorderLayout());

        JPanel boutons = new JPanel( new GridLayout(1,2,5,5));
            add = new JButton("Ajouter joueur");
                add.addActionListener(this);
                add.setVisible(true);
            boutons.add(add);
            remove = new JButton("Retirer joueur");
                remove.addActionListener(this);
                remove.setVisible(false);
            boutons.add(remove);
        add(boutons,"South");

        String[] couleurs = {"Rouge","Vert","Bleu","Jaune"};

        joueurs = new JPanel( new GridLayout(4,2,5,5));
            for ( int i = 0 ; i < 4 ; i++ )
            {
                JLabel lab = new JLabel("Joueur " + couleurs[i] + " :");
                JTextField text = new JTextField();
                if ( i >= 2 )
                {
                    lab.setVisible(false);
                    text.setVisible(false);
                }
                joueurs.add(lab);
                joueurs.add(text);
				alField.add(text);
            }
        add(joueurs);
        setVisible(true);
    }

    void maj()
    {
        if ( alJoueur.size() > 2 )
            remove.setVisible(true);
        else
            remove.setVisible(false);
        if ( alJoueur.size() < 4 )
            add.setVisible(true);
        else
            add.setVisible(false);
    }

    private void addJoueur()
    {
        alJoueur.add("");
        int toAdd = alJoueur.size();
        joueurs.getComponent((toAdd*2)-1).setVisible(true);
        joueurs.getComponent((toAdd*2)-2).setVisible(true);
    }

    private void removejoueur()
    {
        int toRm = alJoueur.size();
        alJoueur.remove(toRm-1);
        joueurs.getComponent((toRm*2)-1).setVisible(false);
        joueurs.getComponent((toRm*2)-2).setVisible(false);
    }

    public String[] getJoueurs()
    {
        String[] retour = new String[alJoueur.size()];
        for ( int i = 0 ; i < alJoueur.size() ; i++ )
		{
			retour[i] = alField.get(i).getText();
		}
        return retour;
    }

    public void actionPerformed(ActionEvent e)
    {
        if ( e.getSource() == add ) addJoueur();
        if ( e.getSource() == remove ) removejoueur();
        maj();
    }
}
