package twistlock;

import twistlock.job.Container;
import twistlock.job.Player;
import twistlock.job.Twistlock;
import twistlock.window.Window;

import javax.swing.*;


/**
 * Main controller of the MVC model, managing the mulitple important values of the game.
 * @author Javane
 * @version 2018-03-26
 * TODO améliorer le display des player panel + changer la couleur du log
 */
public class Controller
{
	/** Single instance of the {@link Controller}. */
	private static Controller 	singleton;
	/** Set of the players participating to the the twistlock game. */
	private Player[] 			players;
	/** The index of the player whose it is the turn. */
	private int 				currentPlayer;

	/** Set of the containers forming the game canvas. */
	private Container[][] 		containers;
	/** Frame forming the user interface of the game */
	private Window 				window;


	private Controller ()
	{
		window = new Window();
	}


	public void createGame (String... players)
	{
		createGame((int)(Math.random() * 10) + 6, (int)(Math.random() * 8) + 3, players);
	}

	public void createGame (int width, int height, String... players)
	{
		Player.resetId();
		this.currentPlayer = 0;

		this.players = new Player[players.length];
		for (int i = 0; i < this.players.length; i++)
		{
			this.players[i] = new Player(players[i]);
		}

		int rowCount = height;
		int colCount = width;

		Twistlock[][] twistlocks = new Twistlock[colCount + 1][rowCount + 1];
		for (int i = 0; i < twistlocks.length; i++)
		{
			for (int j = 0; j < twistlocks[i].length; j++)
			{
				twistlocks[i][j] = new Twistlock();
			}
		}

		containers = new Container[colCount][rowCount];
		for (int i = 0; i < containers.length; i++)
		{
			for (int j = 0; j < containers[i].length; j++)
			{
				containers[i][j] = 	new Container(i, j,
			                        	twistlocks[i][j], twistlocks[i + 1][j],
										twistlocks[i][j + 1], twistlocks[i + 1][j + 1]
									);
			}
		}

		window.setToGame();
	}

	/**
	 * Checks if the game is finished, which can be reached if all the players have used the totality of their locks,
	 * or if the locks of the containers are all set.
	 * @return True if the game is finished, otherwise false.
	 */
	public boolean isFinished ()
	{
		boolean isFinished = true;

		// Checks if the all the containers have their lock set
		for (int i = 0 ; i < containers.length ; i++)
			for (int j = 0 ; j < containers[i].length ; j++)
				for (int coin = 1 ; coin < 5 ; coin++)
					if (containers[i][j].getLock(coin).getOwner() == -1)
						isFinished = false;

		if (isFinished)
			return true;

		// Checks if all the players have used all their locks.
		for (int i = 0 ; i < players.length ; i++)
			if (players[i].hasTwistlock())
				return false;

		return true;
	}

	/**
	 * Perform an action on a certain lock belonging to a container referenced by its coordinates.
	 * @param row Row index of the container.
	 * @param col Column index of the container.
	 * @param corner Corner index of the container, referencing a certain lock.
	 * @return True if an error must be displayed, otherwise false.
	 */
	public boolean doAction (int row, int col, int corner)
	{
	    boolean toReturn = true;
		// If the values don't exist, the player loses two twistlocks
		if (col >= containers.length || row >= containers[col].length || corner > 4 ||
				row < 0 || col < 0 || corner <= 0)
		{
			Player player = this.players[this.currentPlayer];
			player.useTwistlock(2);
			toReturn = false;
		}

		// Otherwise, the lock is captured by the player and is now his
        if (toReturn)
		    toReturn = containers[col][row].capture(corner, this.players[this.currentPlayer]);

		if (this.nextPlayer() == false && toReturn == false)
			toReturn = true;

		return toReturn;
	}

	/**
	 * Updates the current player to make the next player play, or end the game if it ended.
	 * @return True if the turn was set to the next player, false if the game has ended.
	 */
	public boolean nextPlayer ()
	{
		if (!isFinished())
		{
			do
			{
				this.currentPlayer = (this.currentPlayer + 1) % this.players.length;
			} while ( !this.players[this.currentPlayer].hasTwistlock() );
			window.changeColor(this.currentPlayer);
			window.repaint();

			return true;
		}
		else
		{
			String endMsg = "";
			for (int i = 0, n = players.length; i < n; i++)
			{
				Player player = players[i];
				endMsg += String.format(" - %-10s : %d%s", player.getPseudo(), player.getScore(), (i == n-1) ? "" : "\n");
			}
			window.repaint();

			// Displays a recap window of the scores of every player
			JOptionPane d = new JOptionPane();
			d.showMessageDialog( this.window.getContentPane(), endMsg,"Récapitulatif", JOptionPane.INFORMATION_MESSAGE);

			// Bring the players back to the menu
			this.window.setToMenu();

			return false;
		}
	}


	/*-------------*/
	/*   GETTERS   */
	/*-------------*/

	/**
	 * Gets the instance of the controller.
	 * @return Single instance of the controller.
	 */
	public static Controller getController ()
	{
		if (singleton == null) {
			singleton = new Controller();
		}
		return singleton;
	}

	/**
	 * Gets the players playing the game.
	 * @return The set of players participating to the game.
	 */
	public Player[] getPlayers ()
	{
		return players;
	}

	/**
	 * Gets the containers displayed in the game canvas.
	 * @return Set of the containers of the game canvas.
	 */
	public Container[][] getContainers()
	{
		return containers;
	}


	/**
	 * Main function launching the program by creating a window and attaching the menu to it.
	 * @param args Possible arguments of the function.
	 */
	public static void main (String[] args)
	{
		getController();

	}
}
